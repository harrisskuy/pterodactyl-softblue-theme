
@extends('layouts.master')

@section('content')
<div class="container mt-4">
    <h1 class="text-primary">Welcome to SoftBlue Panel</h1>
    @yield('subcontent')
</div>
@endsection
