# SoftBlue Theme for Pterodactyl

A simple soft blue theme with light and dark mode support. Includes layout and navbar modifications.

## Installation

```bash
bash install.sh
php artisan view:clear
php artisan optimize
```

Place this inside your Pterodactyl root directory.
