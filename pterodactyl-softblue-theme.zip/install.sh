#!/bin/bash
echo "Menginstal theme SoftBlue ke Pterodactyl..."

cp -r public/themes/softblue /var/www/pterodactyl/public/themes/
cp -r resources/views/* /var/www/pterodactyl/resources/views/

echo "Theme berhasil diinstal. Jalankan:"
echo "php artisan view:clear && php artisan optimize"
